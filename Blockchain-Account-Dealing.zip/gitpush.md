git init
git remote add origin https://github.com/ShiroRinS/Blockchain-Account-Dealing.git

# Check current branches 

git branch

# Create and switch to a new branch
git checkout -b buddy-branch

# Stage changes
git add .

# Commit changes
git commit -m "unbox truffle"

# Push the new branch to GitHub
git push -u origin buddy-branch

# Switch back to the main branch
git checkout main